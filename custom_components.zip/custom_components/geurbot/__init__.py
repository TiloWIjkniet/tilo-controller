
"""Home Assistant integration for GeurBot devices."""

from __future__ import annotations

import hashlib
import json
import logging

from copy import deepcopy
from pathlib import Path

from homeassistant.config_entries import ConfigEntry
from homeassistant.core import HomeAssistant
from homeassistant.components.http import StaticPathConfig
from homeassistant.components import frontend, panel_custom
from homeassistant.helpers.update_coordinator import UpdateFailed
from homeassistant.helpers.aiohttp_client import async_get_clientsession
from homeassistant.util import dt as dt_util

from .const import DOMAIN, PLATFORMS, PANEL_TITLE, PANEL_ICON
from .storage import GeurBotStore
from .api import async_register_services
from .coordinator import GeurBotCoordinator
from .backend.core.device_manager import DeviceManager

from .backend.api.notification_settings import (
    set_settings_provider,
    DEFAULT_NOTIFICATION_SETTINGS,
    merge_settings,
    validate_settings,
)

from .backend.api.system_view import GeurBotSystemView

from .backend.notification.notifications import (
    notification_manager,
    send_notification,
)

from .backend.automations.fragrance_monitor import FragranceMonitor
from .backend.automations.schedule_runner import ScheduleRunner
from .backend.communication.esp_client import set_shared_session

from .views import (
    GeurBotApiView,
    GeurBotRootApiView,
    GeurBotDevicesAddView,
    GeurBotNotificationTargetsView,
)


_LOGGER = logging.getLogger(__name__)


# ==================================================
# HOME ASSISTANT SETUP
# ==================================================

async def async_setup(
    hass: HomeAssistant,
    config: dict,
) -> bool:
    """Set up routes and services once for this HA instance."""

    async_register_services(hass)

    hass.http.register_view(GeurBotApiView())
    hass.http.register_view(GeurBotRootApiView())
    hass.http.register_view(GeurBotDevicesAddView())
    hass.http.register_view(GeurBotSystemView())
    hass.http.register_view(GeurBotNotificationTargetsView())

    return True


# ==================================================
# CONFIG ENTRY SETUP
# ==================================================

async def async_setup_entry(
    hass: HomeAssistant,
    entry: ConfigEntry,
) -> bool:
    """Set up GeurBot from a config entry."""

    _LOGGER.info("GeurBot-integratie wordt gestart")

    # ==================================================
    # PERSISTENTE OPSLAG LADEN
    # ==================================================

    store = GeurBotStore(hass)
    stored = await store.async_load()

    if not isinstance(stored, dict):
        stored = {}

    set_shared_session(
        async_get_clientsession(hass)
    )

    # ==================================================
    # DEVICE MANAGER INITIALISEREN
    # ==================================================

    manager = DeviceManager()

    devices = stored.get("devices", {})

    if isinstance(devices, dict):
        for device in devices.values():
            if (
                isinstance(device, dict)
                and device.get("device_id")
            ):
                manager.registry.add(device)

    runtime = {
        "store": store,
        "device_manager": manager,
        "coordinators": {},
        "entry": entry,
        "entity_adders": {},
    }

    hass.data.setdefault(DOMAIN, {})
    hass.data[DOMAIN] = runtime

    # ==================================================
    # COORDINATORS VOOR BESTAANDE APPARATEN
    # ==================================================

    for device_id, device in manager.registry.devices.items():
        coordinator = GeurBotCoordinator(hass, device)

        runtime["coordinators"][device_id] = coordinator

        try:
            await coordinator.async_config_entry_first_refresh()

        except UpdateFailed as err:
            _LOGGER.warning(
                "GeurBot %s is momenteel niet bereikbaar: %s",
                device_id,
                err,
            )

    # ==================================================
    # APPARAATOPSLAG
    # ==================================================

    async def persist_devices() -> None:
        await store.async_save_devices(
            manager.get_devices()
        )

    manager.on_devices_changed = persist_devices

    # ==================================================
    # NIEUWE APPARATEN VERWERKEN
    # ==================================================

    async def handle_device_found(device):
        await persist_devices()

        device_id = device["device_id"]

        coordinator = runtime["coordinators"].get(device_id)

        if coordinator is None:
            coordinator = GeurBotCoordinator(
                hass,
                device,
            )

            runtime["coordinators"][device_id] = coordinator

        await coordinator.async_refresh()

        for adder in runtime["entity_adders"].values():
            adder(coordinator)

    manager.on_device_found = handle_device_found

    # ==================================================
    # NOTIFICATIE-INSTELLINGEN HERSTELLEN OF MIGREREN
    # ==================================================

    if store.data.get("notification_settings") is None:
        legacy_file = (
            Path(__file__).parent
            / "backend"
            / "data"
            / "notification_settings.json"
        )

        def read_legacy_settings():
            try:
                with legacy_file.open(
                    "r",
                    encoding="utf-8",
                ) as legacy:
                    value = json.load(legacy)

                return value if isinstance(value, dict) else None

            except (
                OSError,
                ValueError,
                TypeError,
            ):
                return None

        legacy_settings = await hass.async_add_executor_job(
            read_legacy_settings
        )

        settings = merge_settings(
            deepcopy(DEFAULT_NOTIFICATION_SETTINGS),
            legacy_settings or {},
        )

        try:
            validate_settings(settings)

        except (
            ValueError,
            TypeError,
            KeyError,
        ) as err:
            _LOGGER.warning(
                "Oude notificatie-instellingen zijn ongeldig. "
                "Standaardinstellingen worden gebruikt: %s",
                err,
            )

            settings = deepcopy(
                DEFAULT_NOTIFICATION_SETTINGS
            )

        store.data["notification_settings"] = settings

        await store.async_save()

        _LOGGER.info(
            "Notificatie-instellingen hersteld of gemigreerd"
        )

    # ==================================================
    # NOTIFICATIE-INSTELLINGEN PROVIDER EN WRITER
    # ==================================================

    def get_notification_settings():
        """Return the current notification settings."""

        settings = store.data.get("notification_settings")

        if not isinstance(settings, dict):
            return deepcopy(DEFAULT_NOTIFICATION_SETTINGS)

        return settings

    async def persist_notification_settings(settings):
        """Persist updated notification settings."""

        store.data["notification_settings"] = deepcopy(
            settings
        )

        await store.async_save()

        _LOGGER.debug(
            "Notificatie-instellingen opgeslagen"
        )

    set_settings_provider(
        get_notification_settings,
        persist_notification_settings,
    )

    # ==================================================
    # NOTIFICATIES VERWERKEN
    # ==================================================

    async def notification_handler(**notification):
        """Send notifications through selected HA targets."""

        return await send_notification(
            hass,
            notification_type=notification.get(
                "notification_type",
                "event",
            ),
            title=notification.get(
                "title",
                "GeurBot",
            ),
            message=notification.get(
                "message",
                "",
            ),
            device_id=notification.get("device_id"),
            details=notification.get("details"),
        )

    # ==================================================
    # NOTIFICATIEMANAGER CONFIGUREREN
    # ==================================================

    notification_manager.set_handler(
        notification_handler
    )

    notification_manager.set_now_provider(
        dt_util.now
    )

    notification_manager.restore_state(
        store.data.get("notification_state")
    )

    # ==================================================
    # NOTIFICATIESTATUS OPSLAAN
    # ==================================================

    async def persist_notification_state(state):
        """Persist notification manager state."""

        store.data["notification_state"] = state

        await store.async_save()

    notification_manager.set_persist_handler(
        persist_notification_state
    )

    # ==================================================
    # NOTIFICATIEMANAGER STARTEN
    # ==================================================

    await notification_manager.start()

    _LOGGER.info(
        "GeurBot-notificatiemanager is gestart"
    )

    # ==================================================
    # FRAGRANCE MONITOR INITIALISEREN
    # ==================================================

    fragrance_monitor = FragranceMonitor(manager)

    # ==================================================
    # OPGESLAGEN SCHEMA-UITVOERINGEN HERSTELLEN
    # ==================================================

    stored_schedule_keys = [
        tuple(item)
        for item in store.data.get(
            "metadata",
            {},
        ).get(
            "schedule_last_executed",
            [],
        )
        if (
            isinstance(item, list)
            and len(item) == 3
        )
    ]

    # ==================================================
    # SCHEMASTATUS OPSLAAN
    # ==================================================

    async def persist_schedule_state(executed):
        store.data.setdefault(
            "metadata",
            {},
        )["schedule_last_executed"] = [
            list(item)
            for item in executed
        ]

        await store.async_save()

    schedule_runner = ScheduleRunner(
        manager,
        now_provider=dt_util.now,
        executed_schedules=stored_schedule_keys,
        on_state_changed=persist_schedule_state,
    )

    # ==================================================
    # ACHTERGRONDPROCESSEN STARTEN
    # ==================================================

    await fragrance_monitor.start()
    await schedule_runner.start()

    # ==================================================
    # ACHTERGRONDTaken STOPPEN BIJ UNLOAD
    # ==================================================

    async def stop_background_tasks():
        """Stop all GeurBot background tasks."""

        _LOGGER.info(
            "GeurBot-achtergrondprocessen worden gestopt"
        )

        await fragrance_monitor.stop()
        await schedule_runner.stop()
        await notification_manager.stop()

    entry.async_on_unload(
        stop_background_tasks
    )

    # ==================================================
    # UPDATE LISTENER
    # ==================================================

    entry.async_on_unload(
        entry.add_update_listener(
            async_reload_entry
        )
    )

    # ==================================================
    # FRONTENDBESTANDEN BESCHIKBAAR MAKEN
    # ==================================================

    frontend_dir = (
        Path(__file__).parent
        / "frontend"
    )

    panel_file = frontend_dir / "panel.js"

    if not panel_file.is_file():
        raise FileNotFoundError(
            f"GeurBot panelbestand ontbreekt: {panel_file}"
        )

    # Bestand asynchroon lezen om de eventloop niet te blokkeren.
    panel_content = await hass.async_add_executor_job(
        panel_file.read_bytes
    )

    panel_hash = hashlib.sha256(
        panel_content
    ).hexdigest()[:12]

    panel_module_url = (
        f"/geurbot_panel.js?v={panel_hash}"
    )

    if not hass.data.get(
        f"{DOMAIN}_static_registered"
    ):
        try:
            await hass.http.async_register_static_paths([
                StaticPathConfig(
                    "/geurbot_static",
                    str(frontend_dir),
                    False,
                ),
                StaticPathConfig(
                    "/geurbot_panel.js",
                    str(panel_file),
                    False,
                ),
            ])

            hass.data[
                f"{DOMAIN}_static_registered"
            ] = True

        except (
            OSError,
            ValueError,
            RuntimeError,
        ) as err:
            _LOGGER.error(
                "GeurBot frontend/paneelbestanden konden niet "
                "worden gepubliceerd: %s",
                err,
            )

            raise

    # ==================================================
    # GEURBOT ZIJPANEEL REGISTREREN
    # ==================================================

    if not hass.data.get(
        f"{DOMAIN}_panel_registered"
    ):
        await panel_custom.async_register_panel(
            hass,
            webcomponent_name="ha-panel-geurbot",
            frontend_url_path=DOMAIN,
            sidebar_title=PANEL_TITLE,
            sidebar_icon=PANEL_ICON,
            module_url=panel_module_url,
            embed_iframe=False,
            require_admin=False,
        )

        hass.data[
            f"{DOMAIN}_panel_registered"
        ] = True

        _LOGGER.info(
            "GeurBot-zijpaneel geregistreerd via %s",
            panel_module_url,
        )

    # ==================================================
    # PLATFORMS LADEN
    # ==================================================

    await hass.config_entries.async_forward_entry_setups(
        entry,
        PLATFORMS,
    )

    _LOGGER.info(
        "GeurBot-integratie succesvol gestart"
    )

    return True


# ==================================================
# CONFIG ENTRY UNLOAD
# ==================================================

async def async_unload_entry(
    hass: HomeAssistant,
    entry: ConfigEntry,
) -> bool:
    """Unload the integration."""

    unload_ok = await hass.config_entries.async_unload_platforms(
        entry,
        PLATFORMS,
    )

    if unload_ok:
        runtime = hass.data.pop(
            DOMAIN,
            None,
        )

        if runtime:
            await runtime["store"].async_save_devices(
                runtime["device_manager"].get_devices()
            )

        if hass.data.pop(
            f"{DOMAIN}_panel_registered",
            False,
        ):
            frontend.async_remove_panel(
                hass,
                DOMAIN,
            )

        _LOGGER.info(
            "GeurBot-integratie succesvol gestopt"
        )

    return unload_ok


# ==================================================
# CONFIG ENTRY RELOAD
# ==================================================

async def async_reload_entry(
    hass: HomeAssistant,
    entry: ConfigEntry,
) -> None:
    """Reload the integration."""

    await hass.config_entries.async_reload(
        entry.entry_id
    )
